package electricity;

public interface TariffProvider {
    boolean isTariffNow();
}
