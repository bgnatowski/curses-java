import org.junit.Test;

import static org.junit.Assert.*;

public class ExampleTest {

    @Test
    public void example(){

    }

}